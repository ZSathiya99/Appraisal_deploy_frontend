import { React, useState } from "react";
import { ChevronDown, Upload, UserStar, UploadCloud, X } from "lucide-react";
import ResearchForm2_6_2 from "./ResearchForm2_6_2";
import ResearchForm2_6_3 from "./ResearchForm2_6_3";

const ResearchForm6 = () => {
  // states
  const [selectedCheck, setSelectedCheck] = useState("No");
  const [files, setFiles] = useState([]);
  const [dropdown1, setDropdown1] = useState(false);
  const [dropdown3, setDropdown3] = useState(false);

  // function for handling radio button click
  const handleCheckbox = async (value) => {
    setSelectedCheck(value);
  };

  // function for handling file uploads
  const handleFileUpload = async (e) => {
    let uploadedFiles = Array.from(e.target.files);

    // Filter out files larger than 5MB
    let validFiles = uploadedFiles.filter((file) => {
      if (file.size > 5 * 1024 * 1024) {
        // 5MB
        alert(`"${file.name}" is larger than 5MB and will not be uploaded.`);
        return false;
      }
      return true;
    });

    // Check total count (already uploaded + new files)
    if (files.length + validFiles.length > 3) {
      alert("More than 3 files are not allowed");
      return;
    }

    // Add to state
    setFiles((prev) => [...prev, ...validFiles]);
  };

  // function to open and close the dropdown1
  const hanldeDropdown = (key) => {
    if (key == "d1") {
      setDropdown1(!dropdown1);
    }
    if (key == "d2") {
      setDropdown2(!dropdown2);
    }
    if (key == "d3") {
      setDropdown3(!dropdown3);
    }
  };
  return (
    <>
      <div className="input-container-2 border border-[#AAAAAA] p-4  bg-white  rounded-xl grid gap-4 grid-cols-12">
        <div className="first-container pr-3 border-r border-gray-400 col-span-10">
          {/* .heading / question  */}
          <div>
            <h1 className="text-lg font-medium">
              2.6 Patent Published <span className="text-red-500">*</span>
            </h1>
            <h1 className="text-gray-400 font-medium mx-6">
              1 Point / Patent (Max - 3 poinst)
            </h1>
          </div>
          {/* input container  */}
          <div className="checkbox-container mt-2 px-6 flex items-center gap-4">
            <div className=" flex items-center gap-2 ">
              <input
                type="checkbox"
                className="scale-125 cursor-pointer"
                checked={selectedCheck == "Yes" ? true : false}
                onChange={() => setSelectedCheck("Yes")}
              />
              <label className="text-[#6f7282]">Yes</label>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                className="scale-125 cursor-pointer"
                checked={selectedCheck == "No" ? true : false}
                onChange={() => setSelectedCheck("No")}
              />
              <label className="text-[#6f7282]">No</label>
            </div>
          </div>
          {/* attachment container  */}
          <div className="dropdown-attachment-container px-6">
            {/* Dropdown  */}
            {selectedCheck == "Yes" && (
              <div className="dropdown-container relative flex items-center gap-2 justify-between border-1 border-gray-500 px-4 py-2 mt-2 rounded-md">
                <h1 className="text-gray-600">Number of Patent Published</h1>
                <ChevronDown
                  onClick={() => hanldeDropdown("d1")}
                  className={`text-gray-400 cursor-pointer ${
                    dropdown1 && "rotate-180"
                  } transition-all duration-300`}
                />
                {dropdown1 && (
                  <div className="content-container absolute top-full left-0 bg-white z-1 rounded-md border-1 border-gray-300  w-full shadow-md  shadow-gray-500 ">
                    <button className="py-2 px-4 cursor-pointer border-b-1 border-gray-300 hover:bg-gray-100 text-left w-full">
                      1
                    </button>
                    <button className="py-2 px-4 cursor-pointer border-b-1 border-gray-300 hover:bg-gray-100 text-left w-full">
                      2
                    </button>
                    <button className="py-2 px-4 cursor-pointer border-b-1 border-gray-300 hover:bg-gray-100 text-left w-full">
                      3
                    </button>
                  </div>
                )}
              </div>
            )}
            {/* ========================================================== Form 2 ========================= */}

            <ResearchForm2_6_2 />
            <ResearchForm2_6_3 />
            {/* ======================================== Attachement ================================================================  */}
            <div className="attachment-container  mt-4 border-2 border-dashed rounded-lg  border-[#3ab5a3] text-center relative p-3">
              <div className="content-container text-gray-600 flex items-center gap-2 justify-center">
                <UploadCloud />
                <h1>Add Attachment</h1>
                <h1 className="text-teal-500 underline ">Choose file</h1>
              </div>
              <input
                type="file"
                multiple
                accept=".jpeg, .png .pdf, .doc, .docx"
                onChange={handleFileUpload}
                className="cursor-pointer opacity-0 absolute top-0 right-0 left-0 bottom-0"
              />
            </div>

            {/* attachment preview */}
            <div className="main-container overflow-auto mt-2 flex flex-wrap gap-2">
              {files.map((file, index) => {
                return (
                  <div>
                    <h1 className="bg-gray-50 rounded-md w-fit px-2 py-1 flex items-center gap-2">
                      {file.name.length > 10
                        ? file.name.slice(0, -4)
                        : file.name}{" "}
                      <span>
                        <X className="text-red-400 hover:text-red-600 cursor-pointer" />
                      </span>{" "}
                    </h1>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        {/* marks container  */}
        <div className="second-container col-span-2 text-center">
          <h1 className="text-lg font-medium">Marks</h1>
          <div className="h-[80%] flex items-center justify-center">
            <h1 className="text-[#646464]  text-lg">
              <span className="font-semibold text-[#318179]">0</span> out of 0
            </h1>
          </div>
        </div>
      </div>
    </>
  );
};

export default ResearchForm6;
