import React, { useState } from "react";
import { ChevronDown, Upload, UserStar, UploadCloud, X } from "lucide-react";

const ResearchForm2_6_3 = () => {
  const [selectedCheck, setSelectedCheck] = useState("No");

  const [dropdown3, setDropdown3] = useState(false);
  const hanldeDropdown = (key) => {
    if (key == "d3") {
      setDropdown3(!dropdown3);
    }
  };
  return (
    <>
      <div className="main-container mt-4">
        {/* header  */}
        <div className="header">
          <div>
            <h1 className="text-lg font-medium">
              Design and others <span className="text-red-500">*</span>
            </h1>
            <h1 className="text-gray-400 font-medium ">2 Points / Patent</h1>
          </div>
        </div>
        {/* input container  */}
        <div className="checkbox-container mt-2 flex items-center gap-4">
          <div className=" flex items-center gap-2 ">
            <input
              type="checkbox"
              className="scale-125 cursor-pointer"
              checked={selectedCheck == "Yes" ? true : false}
              onChange={() => setSelectedCheck("Yes")}
            />
            <label className="text-[#6f7282]">Yes</label>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              className="scale-125 cursor-pointer"
              checked={selectedCheck == "No" ? true : false}
              onChange={() => setSelectedCheck("No")}
            />
            <label className="text-[#6f7282]">No</label>
          </div>
        </div>
        {/* Dropdown  */}
        {selectedCheck == "Yes" && (
          <div className="dropdown-container relative flex items-center gap-2 justify-between border-1 border-gray-500 px-4 py-2 mt-2 rounded-md">
            <h1 className="text-gray-600">Number of Patent Published</h1>
            <ChevronDown
              onClick={() => hanldeDropdown("d3")}
              className={`text-gray-400 cursor-pointer ${
                dropdown3 && "rotate-180"
              } transition-all duration-300`}
            />
            {dropdown3 && (
              <div className="content-container absolute top-full left-0 bg-white z-1 rounded-md border-1 border-gray-300  w-full shadow-md  shadow-gray-500 ">
                <button className="py-2 px-4 cursor-pointer border-b-1 border-gray-300 hover:bg-gray-100 text-left w-full">
                  1
                </button>
                <button className="py-2 px-4 cursor-pointer border-b-1 border-gray-300 hover:bg-gray-100 text-left w-full">
                  2
                </button>
                <button className="py-2 px-4 cursor-pointer border-b-1 border-gray-300 hover:bg-gray-100 text-left w-full">
                  3
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
};

export default ResearchForm2_6_3;
